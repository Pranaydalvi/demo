package com.pranay.happ.serviceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pranay.happ.dto.Response;
import com.pranay.happ.entity.Role;
import com.pranay.happ.repo.RoleRepository;
import com.pranay.happ.serviceI.RoleServiceI;

@Service
public class RoleServiceImpl implements RoleServiceI{

	
	@Autowired
	private RoleRepository roleRepository;
	
	@Override
	public Response saveRoleData(Role role) {
		Response response =  new Response();
		Role role2 = roleRepository.save(role);
		if(role2 != null) {
			response.setMsg("Role Data inserted.");
		} else {
			response.setMsg("Role Data not inserted.");
		}
		return response;
	}

}