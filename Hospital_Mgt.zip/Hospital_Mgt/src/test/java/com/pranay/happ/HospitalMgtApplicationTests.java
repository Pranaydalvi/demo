package com.pranay.happ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalMgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
