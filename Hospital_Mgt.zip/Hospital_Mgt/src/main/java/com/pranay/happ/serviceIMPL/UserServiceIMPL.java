package com.pranay.happ.serviceIMPL;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.pranay.happ.dto.ResponseDto;
import com.pranay.happ.entity.Login;
import com.pranay.happ.entity.UserRequest;
import com.pranay.happ.repo.LoginRepository;
import com.pranay.happ.repo.UserRepository;
import com.pranay.happ.serviceI.UserServiceI;
import com.pranay.happ.util.UserRequestIDGenerator;

@Service
public class UserServiceIMPL implements UserServiceI {

	@Autowired
	private LoginRepository loginRepository;
	
	@Autowired
	private JavaMailSender javaMailSender;

	@Override
	public ResponseDto addUserRequest(Login login) {
		ResponseDto responseDto = new ResponseDto();
		if (login.getEmail() == null) {
			responseDto.setMsg("Email cannot be null.");
			return responseDto;
		}
		Login existingLogin = loginRepository.findByEmail(login.getEmail());
		if (existingLogin != null) {
			responseDto.setMsg("User already exists.");
			return responseDto;
		}

		String userId = UserRequestIDGenerator.generateUserID();
		login.getUserRequest().setUsernumber(userId);
		Login login2 = loginRepository.save(login);

		if (login2 != null && login2.getId() > 0) {

			responseDto.setMsg("User Successfully Registered.");
			// Mail Sending Code .
			try{
                MimeMessage message = javaMailSender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(message, true);
                helper.setTo(login.getEmail());
                helper.setSubject("Thanks For Creating Account.");
                helper.setText("<!DOCTYPE html>\r\n" +
                        "<html lang=\"en\">\r\n" +
                        "<head>\r\n" +
                        "    <meta charset=\"UTF-8\">\r\n" +
                        "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" +
                        "    <title>Welcome to Our Service</title>\r\n" +
                        "</head>\r\n" +
                        "<body style=\"background-color: #f2f2f2; font-family: Arial, sans-serif; color: #333;\">\r\n" +
                        "    <div style=\"max-width: 600px; margin: 0 auto; padding: 20px; background-color: #fff; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\">\r\n" +
                        "        <h1 style=\"color: #007bff;\">Welcome, " + login.getUserRequest().getUsernumber() + "!</h1>\r\n" +
                        "        <p>Thank you for creating an account with us. We are thrilled to have you on board!</p>\r\n" +
                        "        <p>Your account number is: <strong>" + login.getUserRequest().getUsernumber() + "</strong></p>\r\n" +
                        "        <p>We look forward to serving you and providing the best experience possible.</p>\r\n" +
                        "        <p>If you have any questions or need assistance, please feel free to contact our support team.</p>\r\n" +
                        "        <p>Best regards,</p>\r\n" +
                        "        <p>The Team</p>\r\n" +
                        "    </div>\r\n" +
                        "</body>\r\n" +
                        "</html>", true);
                javaMailSender.send(message);
			}catch (Exception e) {
				e.printStackTrace();
			}
			return responseDto;
		} else {

			responseDto.setMsg("User Not Successfully Registered.");
			return responseDto;
		}

	}

}