package com.pranay.happ.serviceI;

import com.pranay.happ.dto.Response;
import com.pranay.happ.entity.Role;

public interface RoleServiceI {

	Response saveRoleData(Role role);
}